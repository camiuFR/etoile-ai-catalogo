import os, re, json
from pathlib import Path
import pandas as pd
import streamlit as st
try:
    from openai import OpenAI
except ImportError:
    OpenAI=None

BASE=Path(__file__).parent
st.set_page_config(page_title="Étoile AI",page_icon="⭐",layout="wide")
NAVY="#071A36"; MUSTARD="#E3B21A"; BG="#F7F8FA"; TEXT="#172033"
st.markdown(f"""<style>
.stApp{{background:{BG};color:{TEXT}}}.block-container{{max-width:1400px}}
.hero{{background:linear-gradient(135deg,{NAVY},#12325B);color:white;padding:44px;border-radius:28px;margin-bottom:25px;position:relative}}
.hero:after{{content:"★ ☆ ★ ☆ ★";position:absolute;right:28px;top:22px;color:{MUSTARD};font-size:28px}}
.brand{{letter-spacing:4px;font-family:Georgia,serif}}.hero h1{{font-family:Georgia,serif;font-size:54px}}
.hero h1 span{{color:{MUSTARD}}}.hero p{{font-size:18px;line-height:1.6;max-width:800px}}
.card{{background:white;border-radius:20px;padding:22px;border:1px solid #E4E8EF}}
.result{{background:#FFF9E6;border:2px solid {MUSTARD};border-radius:20px;padding:24px}}
.metric{{background:{NAVY};color:white;border-radius:16px;padding:17px;text-align:center}}
.metric b{{display:block;font-size:27px;color:{MUSTARD}}}
</style>""",unsafe_allow_html=True)

@st.cache_data
def load():
    return (pd.read_csv(BASE/"data/productos.csv"),pd.read_csv(BASE/"data/ingredientes.csv"),
            pd.read_csv(BASE/"data/necesidades.csv"),pd.read_csv(BASE/"data/knowledge.csv"))
products,ingredients,needs,knowledge=load()

def norm(x):
    return re.sub(r"[^a-záéíóúüñ0-9 ]"," ",str(x).lower())
def retrieve(q,n=4):
    tokens=set(norm(q).split()); k=knowledge.copy()
    k["score"]=[len(tokens & set(norm(r["titulo"]+" "+r["contenido"]).split())) for _,r in k.iterrows()]
    return k.sort_values(["score","titulo"],ascending=[False,True]).head(n)
def candidates(q,n=4):
    tokens=set(norm(q).split()); p=products.copy()
    p["score"]=[len(tokens & set(norm(" ".join(str(r[c]) for c in ["nombre","categoria","perfil_aromatico","elementos","espacios_uso"])).split())) for _,r in p.iterrows()]
    return p.sort_values(["score","nombre"],ascending=[False,True]).head(n)

def ai_answer(q,ret,cand):
    key=os.getenv("OPENAI_API_KEY")
    if not key or OpenAI is None: return None,"Modo demo local · API no configurada"
    client=OpenAI(api_key=key); model=os.getenv("OPENAI_MODEL","gpt-4.1-mini")
    instructions="""Eres Étoile AI, asistente de productos ecológicos orientados al BIENESTAR ESTUDIANTIL.
Relaciona la necesidad, preferencias y espacio del estudiante con el catálogo recuperado.
Usa solo la información suministrada. No inventes propiedades. No hagas afirmaciones médicas.
Habla de experiencia aromática, confort y ambiente de estudio. Devuelve JSON con:
problema, espacio, preferencia, producto_id, producto, compatibilidad, razonamiento, evidencia_rag, consejo."""
    payload={"consulta":q,"candidatos":cand.to_dict("records"),"evidencia_rag":ret.to_dict("records")}
    res=client.responses.create(model=model,instructions=instructions,input=json.dumps(payload,ensure_ascii=False))
    try:return json.loads(res.output_text),f"IA activa · {model}"
    except:return {"problema":"Bienestar ambiental","espacio":"Espacio de estudio","preferencia":"Según consulta",
                    "producto_id":cand.iloc[0]["id"],"producto":cand.iloc[0]["nombre"],"compatibilidad":80,
                    "razonamiento":res.output_text,"evidencia_rag":ret["titulo"].tolist(),
                    "consejo":"Usa el producto según sus indicaciones reales."},f"IA activa · {model}"

def demo(q,cand):
    p=cand.iloc[0]; x=norm(q)
    if "lavand" in x: p=products[products.id=="EH001"].iloc[0]
    elif "mostaza" in x or "amarillo" in x: p=products[products.id=="EH005"].iloc[0]
    elif "azul" in x or "marino" in x: p=products[products.id=="EH006"].iloc[0]
    elif "mochila" in x or "llavero" in x: p=products[products.id=="EH007"].iloc[0]
    return {"problema":"Necesidad de bienestar ambiental","espacio":"Espacio de estudio / uso personal",
            "preferencia":"Extraída de la consulta","producto_id":p.id,"producto":p.nombre,
            "compatibilidad":min(95,72+int(p.score)*6),
            "razonamiento":f"El RAG recuperó información del catálogo y seleccionó {p.nombre} por coincidencia con la necesidad.",
            "evidencia_rag":[],"consejo":"Utiliza el producto según las indicaciones reales de Étoile Harmonie."}

st.markdown("""<div class="hero"><div class="brand">☆ ÉTOILE HARMONIE</div>
<h1>ÉTOILE <span>AI</span></h1>
<p><b>Asistente inteligente de productos ecológicos para el bienestar estudiantil.</b><br>
Relaciona necesidades, preferencias y espacios de estudio con nuestro catálogo para generar recomendaciones personalizadas.</p></div>""",unsafe_allow_html=True)

with st.sidebar:
    st.markdown("## ⭐ ÉTOILE AI")
    page=st.radio("Secciones",["Diagnóstico IA","Catálogo","Conocimiento RAG","Arquitectura"])
    st.divider(); st.caption("MVP · Python · Streamlit · RAG · API")

if page=="Diagnóstico IA":
    st.markdown("## ⭐ Diagnóstico inteligente")
    q=st.text_area("¿Qué necesitas?",placeholder="Ej.: Quiero un aroma suave para mi espacio de estudio y prefiero algo floral.",height=130)
    if st.button("⭐ Analizar necesidad",type="primary",use_container_width=True):
        if not q.strip(): st.warning("Escribe una necesidad.")
        else:
            ret=retrieve(q); cand=candidates(q); r,status=ai_answer(q,ret,cand)
            if r is None:r=demo(q,cand)
            st.session_state.update(result=r,status=status,ret=ret,cand=cand)
    if "result" in st.session_state:
        r=st.session_state.result; cols=st.columns(4)
        for c,(a,b) in zip(cols,[("Problema",r.get("problema","—")),("Espacio",r.get("espacio","—")),
                                  ("Preferencia",r.get("preferencia","—")),("Compatibilidad",str(r.get("compatibilidad",0))+"%")]):
            c.markdown(f'<div class="metric">{a}<b>{b}</b></div>',unsafe_allow_html=True)
        st.markdown(f'<div class="result"><h2>⭐ {r.get("producto","—")}</h2><p><b>¿Por qué?</b> {r.get("razonamiento","—")}</p><p><b>Consejo:</b> {r.get("consejo","—")}</p></div>',unsafe_allow_html=True)
        with st.expander("📚 Ver evidencia recuperada por RAG"): st.dataframe(st.session_state.ret,use_container_width=True,hide_index=True)
        with st.expander("🔎 Ver candidatos considerados"): st.dataframe(st.session_state.cand,use_container_width=True,hide_index=True)
        st.caption(st.session_state.status)

elif page=="Catálogo":
    st.markdown("## ⭐ Catálogo Étoile Harmonie")
    st.write("Productos ecológicos orientados al bienestar estudiantil.")
    st.dataframe(products,use_container_width=True,hide_index=True)

elif page=="Conocimiento RAG":
    st.markdown("## ⭐ Conocimiento utilizado por la IA")
    st.write("Los aportes se expresan como características del ambiente y experiencia aromática, no como tratamientos médicos.")
    st.dataframe(ingredients,use_container_width=True,hide_index=True)
    st.markdown("### Necesidades de ejemplo"); st.dataframe(needs,use_container_width=True,hide_index=True)

else:
    st.markdown("## ⭐ Arquitectura")
    st.code("""USUARIO
  ↓
STREAMLIT — MVP
  ↓
PYTHON
  ├── productos.csv
  ├── ingredientes.csv
  ├── necesidades.csv
  └── knowledge.csv
          ↓
      RAG / recuperación
          ↓
      API + LLM
          ↓
      AGENTE / decisión
          ↓
 RECOMENDACIÓN PERSONALIZADA
  ↓
USUARIO""")
    st.info("La IA interpreta la necesidad, recupera conocimiento del catálogo y genera una recomendación explicada.")

st.markdown("<div style='text-align:center;padding:35px;color:#667085'>⭐ ÉTOILE HARMONIE · Ecológico · Bienestar estudiantil · IA</div>",unsafe_allow_html=True)
