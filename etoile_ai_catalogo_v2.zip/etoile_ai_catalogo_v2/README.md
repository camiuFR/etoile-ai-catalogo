# Étoile AI — MVP local

## Ejecutar
```bash
pip install -r requirements.txt
streamlit run app.py
```
Luego abre la dirección local mostrada por Streamlit (normalmente http://localhost:8501).

## Activar API
PowerShell:
```powershell
$env:OPENAI_API_KEY="TU_CLAVE"
$env:OPENAI_MODEL="gpt-4.1-mini"
streamlit run app.py
```

La app también funciona en modo demo sin API.
